/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package simple_course;

/**
 *
 * @author TryTry
 */
public class HourlyEmployee extends Employee{
    public int wage;
    public int hours;
    public int getEarnings()
    {
        if(hours <= 40)
        {
            return wage * hours;
        }
        else if(hours > 40)
        {
            return (int)(40 * wage + (hours - 40) * wage * 1.5);
        }
        return 0;
    }
}
