/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package simple_course;


/**
 *
 * @author TryTry
 */
public class Simple_course {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Employee[] employees = new Employee[5];
        System.out.print("Test With Sample Data:\n");
        
        SalariedEmployee employee1 = new SalariedEmployee();
        employee1.firstName = "Chealsa1";
        employee1.lastName = "Jon1";
        employee1.weeklySalary = 1200;
        employees[0] = employee1;
        System.out.print("SalariedEmployee, "+employee1.firstName+" "+employee1.lastName+", weekly salary="+employee1.weeklySalary+"\n");
        
        HourlyEmployee employee2 = new HourlyEmployee();
        employee2.firstName = "Chealsa2";
        employee2.lastName = "Jon2";
        employee2.wage = 42;
        employee2.hours = 46;
        employees[1] = employee2;
        System.out.print("HourlyEmployee, "+employee2.firstName+" "+employee2.lastName+", wage="+employee2.wage+", hours="+employee2.hours+"\n");
        
        CommissionEmployee employee3 = new CommissionEmployee();
        employee3.firstName = "Chealsa3";
        employee3.lastName = "Jon3";
        employee3.commissionRate = 60;
        employee3.grossSales = 80;
        employees[2] = employee3;
        System.out.print("CommissionEmployee, "+employee3.firstName+" "+employee3.lastName+", commissionRate="+employee3.commissionRate+", grossSales="+employee3.grossSales+"\n");
        
        BasePlusCommissionEmployee employee4 = new BasePlusCommissionEmployee();
        employee4.firstName = "Chealsa4";
        employee4.lastName = "Jon4";
        employee4.commissionRate = 45;
        employee4.grossSales = 67;
        employee4.baseSalary = 300;
        employees[3] = employee4;
        System.out.print("BasePlusCommissionEmployee, "+employee4.firstName+" "+employee4.lastName+", commissionRate="+employee4.commissionRate+", grossSales="+employee4.grossSales+", baseSalary="+employee4.baseSalary+"\n");
        
        BasePlusCommissionEmployee employee5 = new BasePlusCommissionEmployee();
        employee5.firstName = "Chealsa5";
        employee5.lastName = "Jon5";
        employee5.commissionRate = 53;
        employee5.grossSales = 74;
        employee5.baseSalary = 350;
        employees[4] = employee5;
        System.out.print("BasePlusCommissionEmployee, "+employee5.firstName+" "+employee5.lastName+", commissionRate="+employee5.commissionRate+", grossSales="+employee5.grossSales+", baseSalary="+employee5.baseSalary+"\n");
        
        System.out.print("\n\n\n\n");
        
        System.out.print("Calculating Earnigs . .  \n\n");
        
        System.out.print("Result:\n");
        
        for(int i=0;i<5;i++)
        {
            System.out.print("employee"+(i+1)+" -> "+employees[i].firstName+" "+employees[i].lastName+" , earnings="+employees[i].getEarnings()+"\n");
        }
        
    }
    
}
