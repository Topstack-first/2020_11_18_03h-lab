/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package simple_course;

/**
 *
 * @author TryTry
 */
public class SalariedEmployee extends Employee {
    public int weeklySalary = 200;
    
    public int getEarnings()
    {
        return weeklySalary;
    }
}
